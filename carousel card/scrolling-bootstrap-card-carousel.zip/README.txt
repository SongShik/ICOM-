A Pen created at CodePen.io. You can find this one at https://codepen.io/kreigd/pen/ybYNoN.

 Advance one item at a time, changes to one card per slide on mobile